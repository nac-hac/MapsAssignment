MAPS ASSIGNMENT 1: OPENMP PROGRAMMING � README

GOLDBERG, PETER | HORNUNG, NICO | WORSZECK, SASCHA | SHU 2012



goldberg_hornung_worszeck.zip provides:



# Design

	goldberg_hornung_worszeck_sortout_designs.docx



# Timings

	goldberg_hornung_worszeck_sortout_timings.xlsx



# Header file (necessary for both versions)

	goldberg_hornung_worszeck_sortout_header.h



# Source file v1 - FOR

	goldberg_hornung_worszeck_sortout1.cpp



# Source file v2 - SECTIONS

	goldberg_hornung_worszeck_sortout2.cpp



# Executable v1 - FOR

	goldberg_hornung_worszeck_sortout1.exe



# Executable v2 - SECTIONS

	goldberg_hornung_worszeck_sortout2.exe




hr_timer.h and hr_timer.cpp (not provided in this zip) are necessary